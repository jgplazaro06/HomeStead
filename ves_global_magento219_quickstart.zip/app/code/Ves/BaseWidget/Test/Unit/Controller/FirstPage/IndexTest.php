<?php
/***
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Ves\BaseWidget\Test\Unit\Controller\FirstPage;

class IndexTest extends \Ves\BaseWidget\Test\Unit\Controller\AbstractBasewidgetControllerTest
{
    public function setUp()
    {
        $this->className = 'Ves\BaseWidget\Controller\FirstPage\Index';
        parent::setUp();
    }
}
